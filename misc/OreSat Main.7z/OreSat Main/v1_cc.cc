HEADER OPTIONS
C    SINDA Data generated with Thermal Desktop 6.0 Patch 25
C    Generated on Tue Jun  2 14:56:09 2020
C    From file: SimpleOreSat_v1.dwg
C    Case Set: Cold Case
C    TDUNITS,   Energy   =    J
C    TDUNITS,   Time     =    sec
C    TDUNITS,   Temp     =    C
C    TDUNITS,   Mass     =    kg
C    TDUNITS,   Length   =    m
C    TDUNITS,   Orbit    =    km
C    TDUNITS,   Pressure =    Pa
C    TDUNITS,   Force    =    N
C    TDUNITS,   Angle    =    Degrees
C    TDUNITS,   Volt     =    volt
C    TDUNITS,   Current  =    amp
C    TDUNITS,   Resistance =   ohm
C    Symbol Names, Evaluated values, Input Strings, Comments
C    Alpha_BlackAnno             0.54          0.54         Absportivity of black anno
C    Alpha_PurpleCoating         0.8           0.8          Absorptivity of purple coating on PCB
C    Alpha_SolarPanel            0.92          0.92
C    BatteryHeatDissipation      1.            1            Amount of heat (W) dissipated by battery pack
C    cp_Al                       900.          900          Specific heat of 6061-type2 Al
C    cp_Battery                  837.4         837.4
C    cp_PCB                      1144.         1144         Specific Heat of PCB assuming 97.5% FR4. 2.5% C
C    ElecConn_FortyPinConnector  0.1178        0.1178
C    ElecConn_SolarCardConnector 0.00558       0.00558
C    Epsilon_BlackAnno           0.75          0.75         Emissivity of black annodization
C    Epsilon_PurpleCoating       0.8           0.8          Emissivity of purple coating on PCB
C    Epsilon_SolarPanel          0.85          0.85
C    ex                          ERROR         
C    hrBetaAngle                 0.            0
C    hrEccen                     0.            0
C    hrIllum                     0.            0
C    hrMeanAnom                  180.          180
C    hrPeriod                    5553.62       5553.62      Always in current user units. If programming, use hrPerio...
C    hrPeriodSec                 5553.62       5553.62
C    hrPlanetX                   0.258819      0.258819
C    hrPlanetY                   -1.399950e-13 -1.39995e-13
C    hrPlanetZ                   -0.965926     -0.965926
C    hrPos                       2.            2
C    hrShadowEntry               109.784       109.784
C    hrShadowExit                250.216       250.216
C    hrSpeed                     7.66856       7.66856
C    hrSubSolarMeanAnom          6.113030e-12  6.11303e-12  -180 to 180
C    hrSubSolarTrueAnom          6.113030e-12  6.11303e-12  -180 to 180
C    hrSunX                      1.            1
C    hrSunY                      0.            0
C    hrSunZ                      0.            0
C    hrTime                      2776.81       2776.81      Always in current user units. If programming, use hrTimeS...
C    hrTimeSec                   2776.81       2776.81
C    hrTimeShadowEntry           1693.6        1693.6
C    hrTimeShadowEntrySec        1693.6        1693.6
C    hrTimeShadowExit            3860.02       3860.02
C    hrTimeShadowExitSec         3860.02       3860.02
C    hrTrueAnom                  180.          180
C    hrVelocityX                 -6.099020e-14 -6.09902e-14
C    hrVelocityY                 -1.           -1
C    hrVelocityZ                 1.285910e-13  1.28591e-13
C    k_Al                        167.          167          Conductivity of 6061-type2 Aluminum
C    k_Battery                   300.          300          Dummy conductivity of battery 
C    k_PCB                       12.           12           Conductivity of 2-layer FR4 PCB. Calculated assuming 90% ...
C    MechConn_BatteryToCard      0.108         0.108        Conductance of mechanical connection from battery to batt...
C    MechConn_CardToXFrame       0.144         0.144        Conductance of mechanical connection from PCB to (+x) frame
C    MechConn_CardToYFrames      0.3301        0.3301       Conductance of mechanical connection from PCB to (+/- y) ...
C    MechConn_EndCaps            0.8045        0.8045
C    MechConn_M2                 0.0256        0.0256
C    MechConn_RVT                1.21          1.21
C    rho_Al                      2700.         2700         Density of 6061-type2 Al
C    rho_Battery                 2007.7        2007.7
C    rho_PCB                     2077.         2077         Density of PCB assuming 97.5% FR4, 2.5% Cu
HEADER NODE DATA, FRAMES
            12,    20.,    2.025
            14,    20.,    4.05
            15,    20.,    2.025
            16,    20.,    4.05
            186,    20.,    8.1
            193,    20.,    4.05
            200,    20.,    4.05
            207,    20.,    8.1
            214,    20.,    8.1
            221,    20.,    4.05
            228,    20.,    2.025
            235,    20.,    4.05
            242,    20.,    4.05
            249,    20.,    2.025
            458,    20.,    2.025
            461,    20.,    4.05
            462,    20.,    4.05
            468,    20.,    4.05
            474,    20.,    2.025
            480,    20.,    4.05
            486,    20.,    8.1
            488,    20.,    8.1
            490,    20.,    8.1
            492,    20.,    4.05
            494,    20.,    4.05
            496,    20.,    8.1
            498,    20.,    8.1
            500,    20.,    4.05
            502,    20.,    4.05
            505,    20.,    8.1
            508,    20.,    8.1
            512,    20.,    4.05
            516,    20.,    4.05
            520,    20.,    8.1
            524,    20.,    8.1
            528,    20.,    4.05
            532,    20.,    4.05
            536,    20.,    8.1
            540,    20.,    8.1
            544,    20.,    4.05
            548,    20.,    4.05
            552,    20.,    8.1
            557,    20.,    8.1
            562,    20.,    4.05
            567,    20.,    2.025
            572,    20.,    4.05
            577,    20.,    4.05
            582,    20.,    2.025
            643,    20.,    8.1
            685,    20.,    8.1
            703,    20.,    8.1
            721,    20.,    4.05
            727,    20.,    4.05
            734,    20.,    8.1
            741,    20.,    8.1
            748,    20.,    4.05
            755,    20.,    4.05
            762,    20.,    8.1
            769,    20.,    8.1
            776,    20.,    4.05
            783,    20.,    4.05
            790,    20.,    8.1
            795,    20.,    4.05
            799,    20.,    4.05
HEADER CONDUCTOR DATA, FRAMES
            1,    FRAMES.12,    FRAMES.16,    0.09741667
            2,    FRAMES.12,    FRAMES.458,    7.952381
            3,    FRAMES.12,    FRAMES.462,    0.07157143
            4,    FRAMES.14,    FRAMES.15,    0.07157143
            5,    FRAMES.14,    FRAMES.462,    0.07157143
            6,    FRAMES.14,    FRAMES.468,    15.90476
            7,    FRAMES.14,    FRAMES.490,    0.1948333
            8,    FRAMES.15,    FRAMES.474,    7.952381
            9,    FRAMES.15,    FRAMES.492,    0.09741667
            10,    FRAMES.16,    FRAMES.480,    15.90476
            11,    FRAMES.16,    FRAMES.488,    0.1431429
            12,    FRAMES.16,    FRAMES.494,    0.09741667
            13,    FRAMES.186,    FRAMES.193,    0.1431429
            14,    FRAMES.186,    FRAMES.214,    0.1948333
            15,    FRAMES.186,    FRAMES.540,    31.80952
            16,    FRAMES.186,    FRAMES.769,    0.1948333
            17,    FRAMES.186,    FRAMES.790,    0.1431429
            18,    FRAMES.193,    FRAMES.221,    0.09741667
            19,    FRAMES.193,    FRAMES.544,    15.90476
            20,    FRAMES.193,    FRAMES.776,    0.09741667
            21,    FRAMES.200,    FRAMES.207,    0.1431429
            22,    FRAMES.200,    FRAMES.228,    0.09741667
            23,    FRAMES.200,    FRAMES.548,    15.90476
            24,    FRAMES.200,    FRAMES.783,    0.09741667
            25,    FRAMES.207,    FRAMES.214,    0.1431429
            26,    FRAMES.207,    FRAMES.235,    0.1948333
            27,    FRAMES.207,    FRAMES.552,    31.80952
            28,    FRAMES.207,    FRAMES.790,    0.1948333
            29,    FRAMES.214,    FRAMES.221,    0.1431429
            30,    FRAMES.214,    FRAMES.242,    0.1948333
            31,    FRAMES.214,    FRAMES.557,    31.80952
            32,    FRAMES.221,    FRAMES.249,    0.09741667
            33,    FRAMES.221,    FRAMES.562,    15.90476
            34,    FRAMES.228,    FRAMES.235,    0.07157143
            35,    FRAMES.228,    FRAMES.567,    7.952381
            36,    FRAMES.235,    FRAMES.242,    0.07157143
            37,    FRAMES.235,    FRAMES.572,    15.90476
            38,    FRAMES.242,    FRAMES.249,    0.07157143
            39,    FRAMES.242,    FRAMES.577,    15.90476
            40,    FRAMES.249,    FRAMES.582,    7.952381
            41,    FRAMES.458,    FRAMES.461,    0.07157143
            42,    FRAMES.458,    FRAMES.480,    0.09741667
            43,    FRAMES.461,    FRAMES.462,    15.90476
            44,    FRAMES.461,    FRAMES.468,    0.07157143
            45,    FRAMES.461,    FRAMES.486,    0.1948333
            46,    FRAMES.462,    FRAMES.488,    0.1948333
            47,    FRAMES.468,    FRAMES.474,    0.07157143
            48,    FRAMES.468,    FRAMES.643,    0.1948333
            49,    FRAMES.474,    FRAMES.795,    0.09741667
            50,    FRAMES.480,    FRAMES.486,    0.1431429
            51,    FRAMES.480,    FRAMES.799,    0.09741667
            52,    FRAMES.486,    FRAMES.488,    31.80952
            53,    FRAMES.486,    FRAMES.643,    0.1431429
            54,    FRAMES.486,    FRAMES.685,    0.1948333
            55,    FRAMES.488,    FRAMES.490,    0.1431429
            56,    FRAMES.488,    FRAMES.496,    0.1948333
            57,    FRAMES.490,    FRAMES.492,    0.1431429
            58,    FRAMES.490,    FRAMES.498,    0.1948333
            59,    FRAMES.490,    FRAMES.643,    31.80952
            60,    FRAMES.492,    FRAMES.500,    0.09741667
            61,    FRAMES.492,    FRAMES.795,    15.90476
            62,    FRAMES.494,    FRAMES.496,    0.1431429
            63,    FRAMES.494,    FRAMES.502,    0.09741667
            64,    FRAMES.494,    FRAMES.799,    15.90476
            65,    FRAMES.496,    FRAMES.498,    0.1431429
            66,    FRAMES.496,    FRAMES.505,    0.1948333
            67,    FRAMES.496,    FRAMES.685,    31.80952
            68,    FRAMES.498,    FRAMES.500,    0.1431429
            69,    FRAMES.498,    FRAMES.508,    0.1948333
            70,    FRAMES.498,    FRAMES.703,    31.80952
            71,    FRAMES.500,    FRAMES.512,    0.09741667
            72,    FRAMES.500,    FRAMES.721,    15.90476
            73,    FRAMES.502,    FRAMES.505,    0.1431429
            74,    FRAMES.502,    FRAMES.516,    0.09741667
            75,    FRAMES.502,    FRAMES.727,    15.90476
            76,    FRAMES.505,    FRAMES.508,    0.1431429
            77,    FRAMES.505,    FRAMES.520,    0.1948333
            78,    FRAMES.505,    FRAMES.734,    31.80952
            79,    FRAMES.508,    FRAMES.512,    0.1431429
            80,    FRAMES.508,    FRAMES.524,    0.1948333
            81,    FRAMES.508,    FRAMES.741,    31.80952
            82,    FRAMES.512,    FRAMES.528,    0.09741667
            83,    FRAMES.512,    FRAMES.748,    15.90476
            84,    FRAMES.516,    FRAMES.520,    0.1431429
            85,    FRAMES.516,    FRAMES.532,    0.09741667
            86,    FRAMES.516,    FRAMES.755,    15.90476
            87,    FRAMES.520,    FRAMES.524,    0.1431429
            88,    FRAMES.520,    FRAMES.536,    0.1948333
            89,    FRAMES.520,    FRAMES.762,    31.80952
            90,    FRAMES.524,    FRAMES.528,    0.1431429
            91,    FRAMES.524,    FRAMES.540,    0.1948333
            92,    FRAMES.524,    FRAMES.769,    31.80952
            93,    FRAMES.528,    FRAMES.544,    0.09741667
            94,    FRAMES.528,    FRAMES.776,    15.90476
            95,    FRAMES.532,    FRAMES.536,    0.1431429
            96,    FRAMES.532,    FRAMES.548,    0.09741667
            97,    FRAMES.532,    FRAMES.783,    15.90476
            98,    FRAMES.536,    FRAMES.540,    0.1431429
            99,    FRAMES.536,    FRAMES.552,    0.1948333
            100,    FRAMES.536,    FRAMES.790,    31.80952
            101,    FRAMES.540,    FRAMES.544,    0.1431429
            102,    FRAMES.540,    FRAMES.557,    0.1948333
            103,    FRAMES.544,    FRAMES.562,    0.09741667
            104,    FRAMES.548,    FRAMES.552,    0.1431429
            105,    FRAMES.548,    FRAMES.567,    0.09741667
            106,    FRAMES.552,    FRAMES.557,    0.1431429
            107,    FRAMES.552,    FRAMES.572,    0.1948333
            108,    FRAMES.557,    FRAMES.562,    0.1431429
            109,    FRAMES.557,    FRAMES.577,    0.1948333
            110,    FRAMES.562,    FRAMES.582,    0.09741667
            111,    FRAMES.567,    FRAMES.572,    0.07157143
            112,    FRAMES.572,    FRAMES.577,    0.07157143
            113,    FRAMES.577,    FRAMES.582,    0.07157143
            114,    FRAMES.643,    FRAMES.703,    0.1948333
            115,    FRAMES.643,    FRAMES.795,    0.1431429
            116,    FRAMES.685,    FRAMES.703,    0.1431429
            117,    FRAMES.685,    FRAMES.734,    0.1948333
            118,    FRAMES.685,    FRAMES.799,    0.1431429
            119,    FRAMES.703,    FRAMES.721,    0.1431429
            120,    FRAMES.703,    FRAMES.741,    0.1948333
            121,    FRAMES.721,    FRAMES.748,    0.09741667
            122,    FRAMES.721,    FRAMES.795,    0.09741667
            123,    FRAMES.727,    FRAMES.734,    0.1431429
            124,    FRAMES.727,    FRAMES.755,    0.09741667
            125,    FRAMES.727,    FRAMES.799,    0.09741667
            126,    FRAMES.734,    FRAMES.741,    0.1431429
            127,    FRAMES.734,    FRAMES.762,    0.1948333
            128,    FRAMES.741,    FRAMES.748,    0.1431429
            129,    FRAMES.741,    FRAMES.769,    0.1948333
            130,    FRAMES.748,    FRAMES.776,    0.09741667
            131,    FRAMES.755,    FRAMES.762,    0.1431429
            132,    FRAMES.755,    FRAMES.783,    0.09741667
            133,    FRAMES.762,    FRAMES.769,    0.1431429
            134,    FRAMES.762,    FRAMES.790,    0.1948333
            135,    FRAMES.769,    FRAMES.776,    0.1431429
            136,    FRAMES.783,    FRAMES.790,    0.1431429
HEADER OUTPUT CALLS, GLOBAL
C Case Set Prop Generated Code

      CALL HNQCAL('ALL')
      CALL TPRINT('ALL')
      IF(NSOL .GT. 1 ) THEN
          IF(TIMEN .GE. TIMEND) THEN
              CALL SAVE('ALL',0)
          ELSE
              CALL SAVE('T',0)
          ENDIF
      ELSE IF( LOOPCT .GT. 0 ) THEN
          CALL SAVE('ALL',0)
      ENDIF

HEADER NODE DATA, SPACE
            -1,    -270.42,    -1.0
HEADER SUBROUTINE
      SUBROUTINE TDHTR
C     This routine is to hold heaters at their midpoint temps
C     for steady state solutions.
      RETURN
      END
      SUBROUTINE TDREL
C     This routine is to release heaters for transient runs
C     for steady state solutions.
F     RETURN
F     END
F     SUBROUTINE TDHTOT
C     This routine prints out heater ontime and cycle summaries
F     RETURN
F     END
F     SUBROUTINE TDHTRST
C     This routine resets heater statistics
F     RETURN
F     END
F     SUBROUTINE TDPREBL
C     This routine executes logic before the build statement
M     CALL COMMON
F     RETURN
F     END
F     SUBROUTINE TDPOSTBL
C     This routine executes logic after the build statement
M     CALL COMMON
F     RETURN
F     END
F     SUBROUTINE TDPOSTSL
C     This routine executes logic after the solution
M     CALL COMMON
F     RETURN
F     END
F     SUBROUTINE BASEPLOT
      CALL COMMON
F     RETURN
F     END
